package kyc

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"encoding/base64"
	"flag"
	"log"
)

/**
@	描述：	数据加密中心
@	时间：	2019年10月24日13:54:42
@	备注：
*/

// -------------------aes   || kyc_aes

// 01 aes 加密 ||  参数：明本 + key
func aesEncrypt(txt string, key string) string {
	// 转成字节数组
	origData := []byte(txt)
	k := []byte(key)
	// 分组秘钥
	// NewCipher该函数限制了输入k的长度必须为16, 24或者32
	block, _ := aes.NewCipher(k)
	// 获取秘钥块的长度
	blockSize := block.BlockSize()
	// 补全码
	origData = PKCS7Padding(origData, blockSize)
	// 加密模式
	blockMode := cipher.NewCBCEncrypter(block, k[:blockSize])
	// 创建数组
	cryted := make([]byte, len(origData))
	// 加密
	blockMode.CryptBlocks(cryted, origData)
	return base64.StdEncoding.EncodeToString(cryted)
}

//	02 aes 解密 ||  参数：密本 + key
func aesDecrypt(signtxt string, key string) string {
	// 转成字节数组
	crytedByte, _ := base64.StdEncoding.DecodeString(signtxt)
	k := []byte(key)
	// 分组秘钥
	block, _ := aes.NewCipher(k)
	// 获取秘钥块的长度
	blockSize := block.BlockSize()
	// 加密模式
	blockMode := cipher.NewCBCDecrypter(block, k[:blockSize])
	// 创建数组
	orig := make([]byte, len(crytedByte))
	// 解密
	blockMode.CryptBlocks(orig, crytedByte)
	// 去补全码
	orig = PKCS7UnPadding(orig)
	return string(orig)
}

//	03 aes 补码 ||  参数：密本 + init
func PKCS7Padding(ciphertext []byte, blocksize int) []byte {
	//AES加密数据块分组长度必须为128bit(byte[16])，密钥长度可以是128bit(byte[16])、192bit(byte[24])、256bit(byte[32])中的任意一个。
	padding := blocksize - len(ciphertext)%blocksize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padtext...)
}

//	03 aes 去码 ||  参数：密本 + init
func PKCS7UnPadding(origData []byte) []byte {
	length := len(origData)
	unpadding := int(origData[length-1])
	return origData[:(length - unpadding)]
}

// -------------------des

// 06 des 加密 ||  参数：明本 + key  string
func desEncrypt(txt, key []byte) string {
	//将字节秘钥转换成block快
	block, _ := des.NewCipher(key)
	//对明文先进行补码操作
	txt = PKCS5Padding([]byte(txt), block.BlockSize())
	//设置加密方式
	blockMode := cipher.NewCBCEncrypter(block, key)
	//创建明文长度的字节数组
	crypted := make([]byte, len(txt))
	//加密明文,加密后的数据放到数组中
	blockMode.CryptBlocks(crypted, txt)
	//将字节数组转换成字符串
	log.Println(base64.StdEncoding.EncodeToString(crypted))
	return base64.StdEncoding.EncodeToString(crypted)
}

// 07 des 解密 ||  参数：密本 + key
func desDecrypt(signtxt string, key []byte) string {
	//将字符串转换成字节数组
	crypted, _ := base64.StdEncoding.DecodeString(signtxt)
	//将字节秘钥转换成block快
	block, _ := des.NewCipher(key)
	//设置解密方式
	blockMode := cipher.NewCBCDecrypter(block, key)
	//创建密文大小的数组变量
	origData := make([]byte, len(crypted))
	//解密密文到数组origData中
	blockMode.CryptBlocks(origData, crypted)
	//去补码
	origData = PKCS5UnPadding(origData)
	//打印明文
	log.Println(string(origData))
	return string(origData)
}

// 08 去除补码 ||  参数：
func PKCS5UnPadding(txt []byte) []byte {
	length := len(txt)
	// 去掉最后一个字节 unpadding 次
	unpadding := int(txt[length-1])
	//解密去补码时需取最后一个字节，值为m，则从数据尾部删除m个字节，剩余数据即为加密前的原文
	return txt[:(length - unpadding)]
}

// 09 实现明文的补码 ||  参数：
func PKCS5Padding(ciphertext []byte, blockSize int) []byte {
	//计算出需要补多少位
	padding := blockSize - len(ciphertext)%blockSize
	//Repeat()函数的功能是把参数一 切片复制 参数二count个,然后合成一个新的字节切片返回
	// 需要补padding位的padding值
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	//把补充的内容拼接到明文后面
	return append(ciphertext, padtext...)
}

// 非对称加密

//生成RSA私钥和公钥，保存到文件中
func GenerateRSAKey() {
	var bits int
	flag.IntVar(&bits, "b", 1024, "密钥长度，默认为1024位")

}
