package kyc

/**
@	描述：	数据加解密
*/

// aes  加密
func AesEncrypt(txt string, key string) string {
	return aesEncrypt(txt, key)
}

// aes  解密
func AesDecrypt(signtxt string, key string) string {
	return aesDecrypt(signtxt, key)
}

// des  加密
func DesEncrypt(txt string, key string) string {
	return desEncrypt([]byte(txt), []byte(key))
}

// des  加密
func DesDecrypt(signtxt string, key string) string {
	return desDecrypt(signtxt, []byte(key))
}
