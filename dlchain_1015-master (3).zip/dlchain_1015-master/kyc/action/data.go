package kyc

const (
	KYC_AES_E string = "KYC@AES@E"
	KYC_AES_D string = "KYC@AES@D"
	KYC_DES_E string = "KYC@DES@E"
	KYC_DES_D string = "KYC@DES@D"
)
