package api

//  kyc

import (
	p "dlchain_1015/kyc/action"
)

/**
@	描述 数据加密
@	时间：	2019年10月24日15:34:33
@	类型	key   string
*/
func Kyc(sol string, key string, txt string) (rep string) {
	//
	switch sol {
	case p.KYC_AES_E:
		rep = p.AesEncrypt(txt, key)
	case p.KYC_AES_D:
		rep = p.AesDecrypt(txt, key)
	case p.KYC_DES_E:
		rep = p.DesEncrypt(txt, key)
	case p.KYC_DES_D:
		rep = p.DesDecrypt(txt, key)
	}
	return rep
}
