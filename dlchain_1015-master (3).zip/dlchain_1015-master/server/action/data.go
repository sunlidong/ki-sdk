package action

// 数登数据

const (
	shudeng_source string = "d2e7b61aa2eee779"
	shudeng_url    string = "http://webyz.dev.fintechp.cn/web/shudeng/api/updateAssetInfoToSd"
)
