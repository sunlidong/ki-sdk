package action

import (
	g "github.com/gin-gonic/gin"
)

//
func TestGet(c *g.Context) {
	testGet(c)
}
func TestPost(c *g.Context) {
	testPost(c)
}

//
func NoticePost(assetState string, assetCode string) (err error) {
	return noticePost(assetState, assetCode)
}
