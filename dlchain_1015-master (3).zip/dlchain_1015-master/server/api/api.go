package api

import (
	"dlchain_1015/server/action"
	g "github.com/gin-gonic/gin"
)

//	数字签名
func TestGet(c *g.Context) {
	action.TestGet(c)
}

//	数字签名
func TestPost(c *g.Context) {
	action.TestPost(c)
}

// NoticePost
func NoticePost(assetState string, assetCode string) (err error) {
	return action.NoticePost(assetState, assetCode)
}
