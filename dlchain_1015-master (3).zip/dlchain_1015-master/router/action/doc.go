package action

import "fmt"

/**
1. 路由  || 接收前段请求  处理

2.
*/

func test() {
	fmt.Println("test")
}
