package action

import (
	g "github.com/gin-gonic/gin"
	"log"
)

/**
* Router
* @lidong sun
* @Time 2019年10月14日11:03:51
* @ get  router
 */
func currentRouter(version int64) *g.Engine {
	gin := &g.Engine{}
	// 选择路由版本
	switch version {
	case Version_01:
		gin = InitRouter()
	case Version_02:
		log.Println("待更新")
	case Version_03:
		log.Println("待更新")
	case Version_04:
		log.Println("待更新")
	case Version_05:
		log.Println("待更新")
	case Version_06:
		log.Println("待更新")
	case Version_07:
		log.Println("待更新")
	case Version_08:
		log.Println("待更新")
	case Version_09:
		log.Println("待更新")
	default:
		return nil
	}
	return gin
}

//
func SelectCurrentRouter(version int64) *g.Engine {
	return currentRouter(version)
}
