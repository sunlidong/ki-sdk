package action

// Version 版本 序列
const (
	//链码数量
	Version_01 int64 = 1
	Version_02 int64 = 2
	Version_03 int64 = 3
	Version_04 int64 = 4
	Version_05 int64 = 5
	Version_06 int64 = 6
	Version_07 int64 = 7
	Version_08 int64 = 8
	Version_09 int64 = 9
)

// Port Gin 端口控制

const (
	Port_01 = ":10082"
	Port_02 = ":10082"
	Port_03 = ":10083"
	Port_04 = ":10084"
	Port_05 = ":10085"
	Port_06 = ":10086"
)
