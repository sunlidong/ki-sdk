package action

import (
	apic "dlchain_1015/controller/api"
	"log"

	g "github.com/gin-gonic/gin"
)

/*
	路由配置设置：
				1. 数据上链 	：	set
				2. 数据查询 	:	query
				3. 组织管理		:	org
				4. 配置查询		:	conf
				5. CA管理		:	ca
				6. 区块链浏览器	：	web
				6. 区块链浏览器	：	sql

*/

func InitRouter() *g.Engine {

	router := g.Default()
	{
		//路由组
		api := router.Group("/api")
		//路由组 v1  上链相关接口
		v1 := api.Group("/v1")

		//------- 数据上链
		set := v1.Group("/set")

		//------- 数据查询
		query := v1.Group("/query")

		//------- 组织联盟
		org := v1.Group("/org")

		//------- 配置解析
		conf := v1.Group("/conf")

		//------- CA
		ca := v1.Group("/ca")

		//------- 区块链浏览器
		web := v1.Group("/web")

		//-------	微分格
		wei := v1.Group("/wei")

		//-------	区块链大屏展示平台
		chain := v1.Group("/v")

		//-------	区块链大屏展示平台
		sql := v1.Group("/sql")

		//-------	测试
		test := v1.Group("/test")

		//
		log.Println("chain=>", chain)

		//-------- 1. 数据上链 	：	set        ||
		{

			//数据上链 	||    统一上链接口
			set.POST("/upload", apic.Upload)

			//数据上链 房地产资产 || realty
			set.POST("/realty", apic.UpLoad)

			//@旧版@ 数据上链 应收账款  || rece  应收账款 2019年11月7日10:42:14
			set.POST("/rece", apic.Upload)

		}

		//-------- 2. 数据查询 	：	query      ||
		{

			//根据ID查找对象
			query.POST("/getId", apic.GetById)

			//标签
			query.POST("/getLabById", apic.GetLabById)

			//根据ID,TIME查找对象
			query.POST("/getUpDateTime", apic.UpLoad)

			//根据ID获取资产相关文件信息
			query.POST("/getAssetsDataByID", apic.UpLoad)

			//查询 data 历史记录日志
			query.POST("/queryHistory", apic.UpLoad)

			// 查询 主键历史记录版本
			query.POST("/queryHistoryByID", apic.UpLoad)

			// 查询资产关联
			query.POST("/queryListByID", apic.UpLoad)

			// 测试 查询 关联
			query.POST("/queryListByIDTest", apic.QueryListByID)

			// 查询资产关联
			query.POST("/queryAssetsListByID", apic.UpLoad)

		}

		//--------------------------------------------------				3. 组织联盟 	：	org        ||---------------------------------//

		{
			/*
				//查询所有联盟关系
				org.POST("/getAllAffiliations", apic.UpLoad)
				//验证一个联盟
				org.POST("/valAffiliation", apic.UpLoad)
				//吊销一个组织
				org.POST("/delAffiliation", apic.UpLoad)
			*/

			//	 V3 ------------------------------------

			//添加一个联盟
			org.POST("/addAffiliation", apic.AddOrg)

			//添加一个联盟
			org.POST("/addOrg", apic.V3_addOrg)

		}

		//--------------------------------------------------				4. 配置解析 	：	conf        ||---------------------------------//

		{

			//查询指定通道详情
			conf.POST("/getBlockData", apic.UpLoad)

			//查询指定通道区块高度
			conf.POST("/getBlockHeight", apic.UpLoad)

			//查询指定通道配置信息
			conf.POST("/getBlockConfig", apic.UpLoad)

			//查询指定高度区块数据
			conf.POST("/getBlockNum", apic.UpLoad)

			//查询HASH对应区块
			conf.POST("/getBlockHash", apic.UpLoad)

			//查询交易ID对应账本信息  TXID
			conf.POST("/getBlockTxid", apic.UpLoad)

		}

		//--------------------------------------------------				5. CA用户 	：	ca        ||---------------------------------//

		{

			// V3 ------------------------
			//注册一个用户
			ca.POST("/setUser", apic.SetUser)
		}

		//--------------------------------------------------				6. 区块链浏览器 	：	web        ||---------------------------------//

		{

			//首页展示 ||区块链世界
			web.POST("/queryBlockInfo", apic.QueryBlockInfo)

			//查看云图配置
			web.POST("/queryConfig", apic.QueryConfig)

			//所选节点动态 ( 通道 )
			web.POST("/queryBlockDynamic", apic.QueryBlockDynamic)

			//一个区块的交易
			web.POST("/queryBlockTransaction", apic.QueryBlockTransaction)

			//浏览器查询
			web.POST("/queryBlockByTxId", apic.QueryBlockByTxId)
		}

		// ---------------------------------------------------- 		   7. 微分格   wei

		// 数据上链
		{

			//	---ca
			//添加一个联盟
			wei.POST("/addOrg", apic.AddOrg)

			//注册一个用户
			wei.POST("/setUser", apic.SetUser)

			// 微分格上链
			wei.POST("/up", apic.UpLoadByBox)

			//	测试添加组织
			wei.POST("/addOrgtest", apic.T_AddOrg)

			//	注册一个用户
			wei.POST("/setUsertest", apic.T_SetUser)

			// 微分格上链
			wei.POST("/uptest", apic.UpLoadByBox)

			// 微分格  -- 查询
			wei.POST("/query", apic.QueryLoadByBox)

			// 微分格  -- 查询 测试
			wei.POST("/queryTest", apic.QueryLoadByBox)

			// 微分格  -- 查询  根据主键查询ID
			wei.POST("/querydata", apic.WQueryData)

		}

		//--------------------------------------------------				8. 区块链大屏展示 	：	v        ||---------------------------------//

		//---------------------------------------	sql 操作 路由
		{
			// sql
			sql.POST("/init", apic.SqlByInit)

			// ------------------------- 查询数据			-- 大屏

			//	大屏@ 合约处理展示 @ 1
			sql.GET("/contract", apic.SqlByConact)

			//	大屏@ 智能合约调用信息表 @ 2
			sql.GET("/large", apic.SqlByLarge)

			//	大屏@ 共识节点信息表 @ 3
			sql.GET("/server", apic.SqlByServer)

			sql.GET("/testserver", apic.SqlByServer)

			//	大屏@ 节点信息统计表 @ 4 DbSvg
			sql.GET("/svg", apic.SqlBySvg)

			//	大屏@ 区块信息表 @ 5 DbBlock TODO
			sql.GET("/blockTest", apic.SqlByBlock)

			//	大屏@ 节点信息交易列表 @ 6 DbDeal
			sql.GET("/deal", apic.SqlByDeal)

			//	大屏@ 资产上链信息表 @ 7 DbAsset
			sql.GET("/asset", apic.SqlByAsset)

			//	大屏@ 根据区块查询信息 @ 8 BlockData TODO 作废
			sql.POST("/queryBlockTest", apic.SqlQueryBlock)

			//	大屏@ 根据区块查询关联10个区块 @ 9 BlockData
			sql.POST("/queryBlockByHeight", apic.SqlQueryBlockByHeight)

			//  展示数据 ：
			//sql.GET("/block", apic.QueryBlockDynamic)
			sql.GET("/block", apic.QueryBlockDynamicList)

			//一个区块的交易  查询指定区块的节点交易信息 100
			sql.POST("/queryBlock", apic.QueryBlockTransaction)

			//	大屏@ 节点信息交易列表 @ 6 DbDeal
			sql.GET("/svgTest", apic.SqlBySvgForAverage)

			//	大屏@ 地理位置列表 2019年12月26日16:21:33
			sql.GET("/geography", apic.SqlBySvgForGeography)

			// 大屏@
			sql.POST("/geography", apic.SqlBySvgForGeography)

			// 大屏@ 查询 展示
			sql.POST("/getNextData", apic.SqlByGetNextData)

			//	大屏@ 资产上链信息表 @ 7 DbAsset
			sql.POST("/assetNext", apic.SqlByAssetNext)

			//	大屏@  复合查询   2020年1月13日19:30:33
			sql.POST("/query", apic.SqlByCompoundQuery)

			//	大屏@  共识节点  三个Tab  2020年1月16日09:45:26 SqlByDealList
			sql.POST("/server", apic.SqlByDealList)

			//	大屏@  抬头列表	2020年1月17日18:07:01
			sql.GET("/home", apic.SqlByRise)
			//
			sql.POST("/geo", apic.SqlByDealGeography)

		}

		//---------------------------------------  旧版本
		{
			//添加一个联盟
			v1.POST("/addAffiliation", apic.AddOrg)

			//注册一个用户
			v1.POST("/setUser", apic.SetUser)

			//哈希世界展示
			v1.POST("/queryBlockInformation", apic.QueryBlockInfo)

			//查看云图配置
			v1.POST("/getDataConfig", apic.QueryConfig)

			//所选节点动态
			v1.POST("/queryBlockDynamicTest", apic.QueryBlockDynamic)

			//所选节点动态 查询
			v1.POST("/queryBlockDynamic", apic.QueryBlockDynamicList)

			//浏览器查询
			v1.POST("/queryBlockDataByTxId", apic.QueryBlockByTxId)
		}

		//	测试
		{
			test.POST("/testchaincode", apic.TestUpload)

			test.POST("/testselect", apic.TestSelect)
		}
	}
	return router
}
