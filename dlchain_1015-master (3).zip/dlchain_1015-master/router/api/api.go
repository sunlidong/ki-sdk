package api

import (
	"dlchain_1015/router/action"
	g "github.com/gin-gonic/gin"
)

//
func Api(actionName string) {
	//
	switch actionName {

	}
	action.SelectCurrentRouter(int64(1))
}

/**
* Router
* @lidong sun
* @Time 2019年10月14日11:03:51
* @  选择路由
* @  参数： get
 */
func setRouter(version int64) *g.Engine {
	//
	return action.SelectCurrentRouter(int64(version))
}

//  获取路由设置 初始化路由
func GetRouter(version int64) *g.Engine {
	return setRouter(version)
}
