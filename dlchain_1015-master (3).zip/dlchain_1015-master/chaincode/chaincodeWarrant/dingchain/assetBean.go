package main

// 资产基本字段
type BaseAsset struct {
	// IsDeleted  bool   `json:"isDeleted"`
	UpdateDate string `json:"updateDate"`
	// 仅用在底层资产中、其Parent有可能为产品、保理
	ParentType string `json:"parentType"`
	ParentID   string `json:"parentID"`
}

type Assets struct {
	BaseAsset
	ProUUID                   string   `json:"prouuid"`
	ProNo                     string   `json:"proNo" pkey:""`
	ProPlatForm               string   `json:"proPlatForm"`
	ProName                   string   `json:"proName"`
	ProAddress                string   `json:"proAddress"`
	ProOwnerName              string   `json:"proOwnerName"`
	ProOwnerId                string   `json:"proOwnerId"`
	ProDisposalName           string   `json:"proDisposalName"`
	ProDisposalId             string   `json:"proDisposalId"`
	ProType                   string   `json:"proType"`
	ProSendTime               string   `json:"proSendTime"`
	ProFinaningNum            string   `json:"proFinaningNum"`
	ProFinancingUnit          string   `json:"proFinancingUnit"`
	ProFinancingEndLine       string   `json:"proFinancingEndLine"`
	ProFinancingEndUnit       string   `json:"proFinancingEndUnit"`
	ProFinancingWay           string   `json:"proFinancingWay"`
	ProFinancingPurpose       string   `json:"proFinancingPurpose"`
	ProEcreditWay             string   `json:"proEcreditWay"`
	ProEcreditAssure          string   `json:"proEcreditAssure"`
	ProEcreditGuaranteeName   string   `json:"proEcreditGuaranteeName"`
	ProEcreditGuaranteeId     string   `json:"proEcreditGuaranteeId"`
	ProEcreditGuaranteeType   string   `json:"proEcreditGuaranteeType"`
	ProReportDuediligenceHash string   `json:"proReportDuediligenceHash"`
	ProReportDuediligenceId   string   `json:"proReportDuediligenceId"`
	ProReportThirdHash        string   `json:"proReportThirdHash"`
	ProReportThirdId          string   `json:"proReportThirdId"`
	ProState                  string   `json:"proState"`
	ProNote                   []string `json:"proNote"`
	ProAttachmentlist         []struct {
		IpfsHash      string `json:"ipfsHash"`
		ProAttachName string `json:"proAttachName"`
		ProAttachType string `json:"proAttachType"`
		ProAttachNo   string `json:"proAttachNo" `
		ProAttachMD   string `json:"proAttachMD"`
		ProAttachAddr string `json:"proAttachAddr"`
	}
}

// 发票信息
type Invoice struct {
	BaseAsset
	InvoiceType          string `json:"invoiceType"`
	InvoiceCode          string `json:"invoiceCode"`
	InvoiceOperationType string `json:"InvoiceOperationType"`
	// 唯一标识
	InvoiceNum            string `json:"invoiceNum" pkey:""`
	IssueDate             string `json:"issueDate"`
	TotalAmount           string `json:"totalAmount"`
	PreTaxAmount          string `json:"preTaxAmount"`
	AmountUnit            string `json:"amountUnit"`
	CheckCodes            string `json:"checkCodes"`
	BuyerTaxNum           string `json:"buyerTaxNum"`
	SellerTaxNum          string `json:"sellerTaxNum"`
	Verified              string `json:"verified"`
	InvoiceAttachmentList []struct {
		IpfsHash          string `json:"ipfsHash"`
		InvoiceAttachName string `json:"invoiceAttachName"`
		InvoiceAttachType string `json:"invoiceAttachType"`
		InvoiceAttachNo   string `json:"invoiceAttachNo"`
		InvoiceAttachMD   string `json:"invoiceAttachMD"`
		InvoiceAttachAddr string `json:"invoiceAttachAddr"`
	} `json:"invoiceAttachmentList"`
}

// 合同信息
type TradingContr struct {
	BaseAsset
	// 唯一标识
	TradingContrNum              string `json:"tradingContrNum" pkey:""`
	TradingContrOperationType    string `json:"tradingContrOperationType"`
	TradingContrName             string `json:"tradingContrName"`
	TradingContrAmount           string `json:"tradingContrAmount"`
	TradingContrAmountUnit       string `json:"tradingContrAmountUnit"`
	TradingContrCurrency         string `json:"tradingContrCurrency"`
	TradingContrPayerCertificate string `json:"tradingContrPayerCertificate"`
	TradingContrPayerName        string `json:"tradingContrPayerName"`
	TradingContrPayeeCertificate string `json:"tradingContrPayeeCertificate"`
	TradingContrPayeeName        string `json:"tradingContrPayeeName"`
	TradingContrSigningDate      string `json:"tradingContrSigningDate"`
	TradingContrFrequency        string `json:"tradingContrFrequency"`
	TradingContrAccountPeriod    string `json:"tradingContrAccountPeriod"`
	TradingContrAttachList       []struct {
		TradingContrAttachName string `json:"tradingContrAttachName"`
		TradingContrAttachTyp  string `json:"tradingContrAttachTyp"`
		TradingContrAttachNo   string `json:"tradingContrAttachNo"`
		TradingContrAttachMD   string `json:"tradingContrAttachMD"`
		TradingContrAttachAddr string `json:"tradingContrAttachAddr"`
		IpfsHash               string `json:"ipfsHash"`
	} `json:"tradingContrAttachList"`
}

// 其他附件
type ExtraInfoAttach struct {
	BaseAsset
	IpfsHash            string `json:"ipfsHash"`
	ExtraInfoFileName   string `json:"extraInfoFileName"`
	ExtraInfoAttachType string `json:"extraInfoAttachType"`
	// 唯一标识
	ExtraInfoAttachNo   string `json:"extraInfoAttachNo" pkey:""`
	ExtraInfoAttachMd   string `json:"extraInfoAttachMd"`
	ExtraInfoAttachAddr string `json:"extraInfoAttachAddr"`
}

// 其他附件
type ProAttachmentlist struct {
	BaseAsset
	BaseType
	BaseUser
	IpfsHash      string `json:"ipfsHash"`
	ProAttachName string `json:"proAttachName"`
	ProAttachType string `json:"proAttachType"`
	// 唯一标识
	ProAttachNo   string `json:"proAttachNo" pkey:""`
	ProAttachMD   string `json:"proAttachMD"`
	ProAttachAddr string `json:"proAttachAddr"`
}

//底层资产
type ArAsset struct {
	BaseAsset
	// 唯一标识
	ArNum            string   `json:"arNum" pkey:""`
	ArPayer          string   `json:"arPayer"`
	ArPayee          string   `json:"arPayee"`
	ArTotalAmount    string   `json:"arTotalAmount"`
	ArNet            string   `json:"arNet"`
	ArDueDate        string   `json:"arDueDate"`
	AssetStatus      string   `json:"assetStatus"`
	AssetAttribute   string   `json:"assetAttribute"`
	TradingContrList []string `json:"tradeContractList"`
	InvoiceAmount    string   `json:"invoiceAmount"`
	InvoiceList      []string `json:"invoiceList"`
	ExtraInfoList    []string `json:"extraInfoList"`
}

// 保理信息
type Factoring struct {
	BaseAsset
	// SendID             string `json:"sendId"`
	// SenderName         string `json:"senderName"`
	// UserName           string `json:"userName"`
	// Token              string `json:"token"`
	// TargetName         string `json:"targetName"`
	FOperationType string `json:"fOperationType"`
	// FStatus            string `json:"fStatus"`
	FAttribute       string `json:"fAttribute"`
	FirstHandAsset   string `json:"firstHandAsset"`
	FPossessor       string `json:"fPossessor"`
	FPossessorTaxNum string `json:"fPossessorTaxNum"`
	DisclosedF       string `json:"disclosedF"`
	RecourseF        string `json:"recourseF"`
	FDuration        string `json:"fDuration"`
	ArTotalAmount    string `json:"arTotalAmount"`
	// 唯一标识
	FContrNum          string `json:"fContrNum" pkey:""`
	FContrName         string `json:"fContrName"`
	FContrAttachAmount string `json:"fContrAttachAmount"`
	FContrAttachList   []struct {
		IpfsHash         string `json:"ipfsHash"`
		FContrAttachName string `json:"fContrAttachName"`
		FContrAttachType string `json:"fContrAttachType"`
		FContrAttachNo   string `json:"fContrAttachNo"`
		FContrAttachMD   string `json:"fContrAttachMD"`
		FContrAttachAddr string `json:"fContrAttachAddr"`
	} `json:"fContrAttachList"`
	FContrTotalAmount            string   `json:"fContrTotalAmount"`
	FinancingPrincipal           string   `json:"financingPrincipal"`
	FinancingInterestTotalAmount string   `json:"financingInterestTotalAmount"`
	FinancingInterestRate        string   `json:"financingInterestRate"`
	FinancingDueDate             string   `json:"financingDueDate"`
	InterestPaymentFrequency     string   `json:"interestPaymentFrequency"`
	ManagementFee                string   `json:"managementFee"`
	FinancingDuration            string   `json:"financingDuration"`
	FFinancingRatio              string   `json:"fFinancingRatio"`
	ArAssetAmount                string   `json:"arAssetAmount"`
	ArAssetList                  []string `json:"arAssetList"`
}

//　产品信息
type Product struct {
	BaseAsset
	SendID     string `json:"sendId"`
	SenderName string `json:"senderName"`
	UserName   string `json:"userName"`
	// TransUUID                string   `json:"transUuid"`
	// MsgUUID                  string   `json:"msgUuid"`
	/** 唯一值使用后台生成的的编号 */
	ProNo     string `json:"proNo" pkey:""`
	PreRegNo  string `json:"preRegNo"`
	RegNo     string `json:"regNo"`
	PreProdNo string `json:"preProdNo"`
	ProdNo    string `json:"prodNo"`
	Status    string `json:"status"`
	AssetUUID string `json:"assetUuid"`

	// 0：保理资产
	// 1：底层资产
	AssetType string `json:"assetType"`

	AssetAmount              string   `json:"assetAmount"`
	AssetScope               string   `json:"assetScope"`
	ProductUUID              string   `json:"productUuid"`
	ProductName              string   `json:"productName"`
	Financier                string   `json:"financier"`
	TotalAmount              string   `json:"totalAmount"`
	PriorAmount              string   `json:"priorAmount"`
	PosteriorAmount          string   `json:"posteriorAmount"`
	Unit                     string   `json:"unit"`
	ProductDuration          string   `json:"productDuration"`
	ProductDenomination      string   `json:"productDenomination"`
	ListingMethod            string   `json:"listingMethod"`
	ListingDate              string   `json:"listingDate"`
	DatedDate                string   `json:"datedDate"`
	ProductInterestRate      string   `json:"productInterestRate"`
	DebtServiceMethod        string   `json:"debtServiceMethod"`
	InterestPaymentFrequency string   `json:"interestPaymentFrequency"`
	RedemptionPrice          string   `json:"redemptionPrice"`
	RedemptionDate           string   `json:"redemptionDate"`
	CallProvision            string   `json:"callProvision"`
	CreditRatingResult       string   `json:"creditRatingResult"`
	CollectionObject         string   `json:"collectionObject"`
	ListingPrice             string   `json:"listingPrice"`
	TrustPlanName            string   `json:"trustPlanName"`
	TrustPlanNum             string   `json:"trustPlanNum"`
	ProductCategory          string   `json:"productCategory"`
	BasicAssetPen            string   `json:"basicAssetPen"`
	CreditorNumber           string   `json:"creditorNumber"`
	ObligorNumber            string   `json:"obligorNumber"`
	Originator               string   `json:"originator"`
	IssuingCarrier           string   `json:"issuingCarrier"`
	RatingAgency             string   `json:"ratingAgency"`
	AccountingFirm           string   `json:"accountingFirm"`
	LawFirm                  string   `json:"lawFirm"`
	MainUnderwriter          string   `json:"mainUnderwriter"`
	AssetList                []string `json:"assetList"`
}

// ------------------------历史追溯 子资产的结构体-----------------------------

//历史追溯、针对产品的子资产
type SubAssetsResult struct {
	ProAttachmentlist []ProAttachmentlist `json:"proAttachmentlist"`
	BaseSurvey        []BaseSurvey        `json:"baseSurvey"`
	BaseReport        []BaseReport        `json:"baseReport"`
}

//子资产的key以及txID信息
type SubAssetKeyAndTxIDResult struct {
	TxID string `json:"txID"`
	Key  string `json:"key"`
}

// 尽调结果 集合 上链
type BaseSurvey struct {
	BaseAsset
	BaseType
	BaseUser
	IpfsHash string `json:"ipfsHash"`
	// 唯一标识
	SurveyNo string `json:"surveyNo" pkey:""`
	//所属资产信息
	FMasterID string `json:fMasterID`
}

// 尽调报告 集合 上链
type BaseReport struct {
	BaseAsset
	BaseType
	BaseUser
	IpfsHash   string `json:"ipfsHash"`
	ReportName string `json:"reportName"`
	ReportType string `json:"reportType"`
	// 唯一标识
	ReportNo   string `json:"reportNo" pkey:""`
	ReportTx   string `json:"reportTx"`
	ReportMD   string `json:"reportMD"`
	ReportAddr string `json:"reportAddr"`

	//所属资产信息
	FMasterID string `json:fMasterID`
}

// 历史记录表
type HistoryLog struct {
	BaseAsset
	// 数据信息
	HisUUID        string `json:"uuid" pkey:""`
	HisCurrentTime string `json:"hisCurrentTime"`
	HisCurrentTx   string `json:"hisCurrentTx"`
	HisPreTime     string `json:"hisPreTime"`
	HisPreTx       string `json:"hisPreTx"`
	HisRemark      string `json:"hisRemark"`

	HisType   string `json:"hisType"`
	HisDataID string `json:"hisDataId"`

	// 操作人信息
	HisOrgID      string `json:"hisOrgId"`
	HisOrgName    string `json:"hisOrgName"`
	HisUserName   string `json:"hisUserName"`
	HisUserID     string `json:"hisUserId"`
	HisUserRemark string `json:"hisUserRemark"`
	HisCreateTime string `json:"hisCreateTime"`
	HisModify     string `json:"hisModify"`
	HisState      string `json:"hisState"`
}

//子资产信息关联主资产信息

type BaseFetter struct {
	FetUUID  string `json:"fetUUID`
	FetTxID  string `json:"fetTxID`
	FetTime  string `json:"fetTime`
	FetTpye  string `json:"fetTpye`
	FetBz    string `json:"fetBz`
	FetState string `json:"fetState`
}

// 资产 子资产集合列表
type BaseAssetsList struct {
	//
	BaseAsset

	SubsetNo    string       `json:"subsetNo`
	SubsetUUID  string       `json:"subsetUUID"  pkey:""`
	SubsetName  string       `json:"subsetName`
	SubsetType  string       `json:"subsetType`
	SubsetState string       `json:"subsetState`
	SubsetList  []BaseAssets `json:"subsetList`
}

//
type BaseAssets struct {
	BstName       string   `json:"bstName`
	BstType       string   `json:"bstName`
	BstUUID       string   `json:"bstUUID`
	BstParentUUID string   `json:"bstParentUUID`
	BstUpDateTime string   `json:"bstUpDateTime`
	BstState      string   `json:"bstState`
	BaseUser      BaseUser `json:"baseUser`
}

// user 信息  ，数据上传的信息
type BaseUser struct {
	//
	BurUseName    string `json:"burUseName`
	BurUseID      string `json:"burUseID`
	BurUseOrgName string `json:"burUseOrgName`
	BurUseOrgID   string `json:"burUseOrgID`
	BurUseType    string `json:"burUseType`
}

// 类型 信息
type BaseType struct {
	BtType  string `json:"btType`
	BtState string `json:"btState`
}

//-------------------------------------------------------2019 08 16 新数据结构上链

/*
应收账款数据结构整理：
资产包：
		资产：（多个）
				1.合同
				2.发票
		融资信息：（单个）
		增信措施信息：（单个）
					1. 担保
					2. 质押
					3. 抵押
		发布人信息：（单个）

*/

//	发布人信息
type AstSendInfo struct {
	AstSenduuid      string `json:"astSenduuid" pigkey:""`
	AstSendfMasterID string `json:"astSendfMasterID`
	AstSendName      string `json:"astSendName`
	AstSendid        string `json:"astSendid`
	AstSendContact   string `json:"astSendContact`
	AstSendTime      string `json:"astSendTime`
}

//	质押品
type AstCreEnsureList struct {
	AstCreEnsuuid      string `json:"astCreEnsuuid piokey:""` // 质押品uuid
	AstCreEnsfMasterID string `json:"astCreEnsfMasterID`      //质押品fMasterID
	AstCreEnsType      string `json:"astCreEnsType`           //质押品类型
	AstCreEnsName      string `json:"astCreEnsName`           // 质押品名称
	AstCreEnsOwner     string `json:"astCreEnsOwner`          //质押品所有人
}

//	抵押品
type AstCrePledgeList struct {
	AstCrePleuuid      string `json:"astCrePleuuid pitkey:""` // 抵押品uuid
	AstCrePlefMasterID string `json:"astCrePlefMasterID `     // 抵押品fMasterID
	AstCrePleType      string `json:"astCrePleType `          // 抵押品类型
	AstCrePleName      string `json:"astCrePleName `          // 抵押品名称
	AstCrePleOwner     string `json:"astCrePleOwner `         // 抵押品所有人
}

// 担保 信息
type AstCreGuarantyList struct {
	AstCreGuauuid       string `json:"astCreGuauuid piakey:""` // 担保uuid
	AstCreGuafMasterID  string `json:"astCreGuafMasterID `     // 担保fMasterID
	AstCreGuaType       string `json:"astCreGuaType `          // 增信措施类型
	AstCreGuaName       string `json:"astCreGuaName `          // 保证人名称
	AstCreGuaManner     string `json:"astCreGuaManner `        // 担保方式
	AstCreGuaEnsureId   string `json:"astCreGuaEnsureId `      // 担保人ID
	AstCreGuaEnsureName string `json:"astCreGuaEnsureName `    // 担保人名称
}

// 担保列表
type AstCreditInfo struct {
	AstCreGuarantyList []AstCreGuarantyList `json:"astCreGuarantyList ` // 担保
	AstCrePledgeList   []AstCrePledgeList   `json:"astCrePledgeList `   // 抵押品
	AstCreEnsureList   []AstCreEnsureList   `json:"astCreEnsureList `   // 质押品

}

// 融资 信息
type AstFinancingInfo struct {
	AstFinuuid        string `json:"astFinuuid" pivkey:""` // 融资uuid
	AstFinfMasterID   string `json:"astFinfMasterID `      // 融资fMasterID
	AstFinPrice       string `json:"astFinPrice `          // 融资金额
	AstCreGuaName     string `json:"astFinLimit `          // 融资期限
	AstCreGuaManner   string `json:"astFinType `           // 融资方式
	AstCreGuaEnsureId string `json:"astFinUsefor `         // 资金用途
}

// 发票  信息
type AstInv struct {
	AstInvuuid           string         `json:"astInvuuid" pkey:""`   // 发票uuid
	AstInvfMasterID      string         `json:"astInvfMasterID `      // 发票fMasterID
	AstInvType           string         `json:"astInvType `           // 发票类型
	AstInvNum            string         `json:"astInvNum `            // 发票号码
	AstInvCode           string         `json:"astInvCode `           // 发票代码
	AstInvChecksum       string         `json:"astInvChecksum `       // 校验码
	AstInvPrice          string         `json:"astInvPrice `          // 发票金额
	AstInvUnit           string         `json:"astInvUnit `           // 金额单位
	AstInvTime           string         `json:"astInvTime `           // 发票开具日期
	AstInvBuyerTaxNum    string         `json:"astInvBuyerTaxNum `    // 购买方纳税识别号
	AstInvSellerTaxNum   string         `json:"astInvSellerTaxNum `   // 销售方纳税识别号
	AstInvCheckResult    string         `json:"astInvCheckResult `    // 发票验真结果
	AstInvAttachmentList AttachmentList `json:"astInvAttachmentList ` // 发票列表
}

// 发票  信息
type AstCon struct {
	AstConuuid           string         `json:"astConuuid" pkey:""`   // 合同uuid
	AstConfMasterID      string         `json:"astConfMasterID `      // 合同fMasterID
	AstConNo             string         `json:"astConNo `             // 合同编号
	AstConName           string         `json:"astConName `           // 合同名称
	AstConPrice          string         `json:"astConPrice `          // 合同金额
	AstConPriceUnit      string         `json:"astConPriceUnit `      // 金额单位
	AstConType           string         `json:"astConType `           // 币种
	AstConPayerTaxNum    string         `json:"astConPayerTaxNum `    // 付款方纳税识别号
	AstConPayerName      string         `json:"astConPayerName `      // 付款方名称
	AstConPayeeTaxNum    string         `json:"astConPayeeTaxNum `    // 收款方纳税识别号
	AstConPayeeName      string         `json:"astConPayeeName `      // 收款方名称
	AstConTime           string         `json:"astConTime `           // 合同签署时间
	AstConCount          string         `json:"astConCount `          // 单次/多次
	AstConDays           string         `json:"astConDays `           // 账期
	AstConAttachmentList AttachmentList `json:"astConAttachmentList ` // 附件列表
}

//	附件 信息
type AttachmentList struct {
	AstAttachNo        string `json:"astAttachNo" pkey:""` //附件附加编号
	IpfsHash           string `json:"ipfsHash `            //IPFS-Hash
	AstAttachfMasterID string `json:"astAttachfMasterID `  //附件附加fMasterID
	AstAttachName      string `json:"astAttachName `       //附件附加名称
	AstAttachType      string `json:"astAttachType `       //附件附加类型
	AstAttachMD        string `json:"astAttachMD `         //附件附MD
	AstAttachAddr      string `json:"astAttachAddr `       //附件附加地址
}

// 资产信息  应收账款信息
type AstAssetsList struct {
	//
	AstAssetsuuid           string   `json:"astAssetsuuid" pkey:""`   //资产
	AstAssetsfMasterID      string   `json:"astAssetsfMasterID `      //外键
	AstAssetsType           string   `json:"astAssetsType `           //资产类型
	AstAssetsIntroduce      string   `json:"astAssetsIntroduce `      //资产简介
	AstAssetsCreditorName   string   `json:"astAssetsCreditorName `   //债权人名称
	AstAssetsCreditorTaxNum string   `json:"astAssetsCreditorTaxNum ` //债权人纳税识别号
	AstAssetsDebtorName     string   `json:"astAssetsDebtorName `     //债务人名称
	AstAssetsDebtorTaxNum   string   `json:"astAssetsDebtorTaxNum `   //债务人纳税识别号
	AstAssetsValuation      string   `json:"astAssetsValuation `      //资产估值
	AstAssetsHonour         string   `json:"astAssetsHonour `         //资产兑付日
	AstAssetsState          string   `json:"astAssetsState `          //当前状态
	AstAssetsPrimeval       string   `json:"astAssetsPrimeval `       //是否为原始资产
	AstContractInfoList     []AstCon `json:"astContractInfoList `     //合同列表
	AstInvoiceInfoList      []AstInv `json:"astInvoiceInfoList `      //发票列表
}

//  资产包 信息
type AstAssetsInfo struct {
	//
	BaseAsset
	AstPackageuuid       string           `json:"astPackageuuid" pidkey:""` //资产包UUID
	AstPackageNo         string           `json:"astPackageNo `             //资产包编号
	AstPackagePlatForm   string           `json:"astPackagePlatForm `       //平台信息-鼎链名称
	AstPackagePlatFormID string           `json:"astPackagePlatFormID `     //平台信息-鼎链ID
	AstPackageName       string           `json:"astPackageName `           //资产包名称
	AstPackageNumber     string           `json:"astPackageNumber `         //资产数量
	AstPackageOwnerName  string           `json:"astPackageOwnerName `      //资产所有人名称
	AstPackageOwnerId    string           `json:"astPackageOwnerId `        //资产所有人ID
	AstPackageSplit      string           `json:"astPackageSplit `          //是否允许拆分
	AstPackageEvaluation string           `json:"astPackageEvaluation `     //综合评价
	AstAssetsList        []AstAssetsList  `json:"astAssetsList `            //合同发票列表
	AstFinancingInfo     AstFinancingInfo `json:"astFinancingInfo `         //融资信息
	AstCreditInfo        AstCreditInfo    `json:"astCreditInfo `            //增信措施信息
	AstSendInfo          AstSendInfo      `json:"astSendInfo `              //发布人信息
}

// 应收账款   主体包
type AstInfo struct {
	BaseAsset
	AstAssetsInfo AstAssetsInfo `json:"astAssetsInfo"`

	// 单个应收账款的UUID
	AstAssetsInfoUUID string `json:"uuid" pkey:""` //资产包UUID
}

//
