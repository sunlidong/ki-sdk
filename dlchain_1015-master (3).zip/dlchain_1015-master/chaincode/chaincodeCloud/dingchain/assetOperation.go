package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"strings"

	"github.com/hyperledger/fabric/core/chaincode/shim"
)

// 资产更新
func updateAssetInternal(stub shim.ChaincodeStubInterface, args []string, asset interface{}) (string, error) {
	var key string
	var err error
	if len(args) != 3 {
		return key, errors.New("Incorrect number of arguments. Expecting 3")
	}
	assetJsonStr := args[1]
	updateTime := args[2]
	logger.Debug("获取到asset:", asset)
	//１ 反序列化传递进来的的对象
	if err := json.Unmarshal([]byte(assetJsonStr), asset); err != nil {
		return key, errors.New("第一次反序列话的时候 出错," + err.Error())
	}
	//2 获取上链key
	key, err = getPkey(asset)
	if err != nil {
		return key, err
	}
	//3 检查是否上链
	assetAsBytes, err := stub.GetState(key)
	if err != nil {
		return key, err
	}
	if assetAsBytes == nil {
		return key, errors.New("The asset  is　not existed! the key :" + key)
	}
	//4 反序列链上对象
	if err := json.Unmarshal(assetAsBytes, asset); err != nil {
		return key, errors.New("4 反序列链上对象 出错," + err.Error())
	}
	//5　获取原有　父级信息
	parentID, parentType := getParentIDAndParentType(asset)
	// 6 为新对象添加 父级信息
	if err := json.Unmarshal([]byte(assetJsonStr), asset); err != nil {
		return key, errors.New("6 为新对象添加 父级信息 出错," + err.Error())
	}
	if err = addParentInfo(parentID, parentType, asset); err != nil {
		return key, err
	}
	// 7 添加push时间
	if err = addUpdateTime(updateTime, asset); err != nil {
		return key, err
	}
	//// 8 　检查上链资产中的子资产是否关联了本资产
	//if err = addRelationShipForSubAsset(stub, asset, key); err != nil {
	//	return key, err
	//}
	// 9　上链
	assetAsBytes, err = json.Marshal(asset)
	if err != nil {
		return key, err
	}
	if err = stub.PutState(key, assetAsBytes); err != nil {
		return key, err
	}
	return key, nil
}

// 获取现有资产的　parentID type
func getParentIDAndParentType(asset interface{}) (string, string) {
	var parentID, parentType string
	switch t := asset.(type) {
	case *Assets:
		parentID = t.ParentID
		parentType = t.ParentType
	case *ProAttachmentlist:
		parentID = t.ParentID
		parentType = t.ParentType
	case *BaseSurvey:
		parentID = t.ParentID
		parentType = t.ParentType
	case *BaseReport:
		parentID = t.ParentID
		parentType = t.ParentType
	}
	return parentID, parentType
}

// 资产上链
func uploadAssetInternal(stub shim.ChaincodeStubInterface, args []string, assetStruct interface{}) (string, error) {
	var key string
	var err error
	if len(args) != 3 {
		return key, errors.New("Incorrect number of arguments. Expecting 3")
	}
	assetJsonStr := args[1]
	updateTime := args[2]
	logger.Debug("开始步骤")
	//１ 反序列化
	if err := json.Unmarshal([]byte(assetJsonStr), assetStruct); err != nil {
		return key, errors.New("//１ 反序列化:" + err.Error())
	}
	//2 获取上链key
	key, err = getPkey(assetStruct)
	if err != nil {
		return key, errors.New("//2 获取上链:" + err.Error())
	}
	//3 检查是否上链
	existed, err := checkIsExisted(stub, key)
	if err != nil {
		return key, errors.New("//3 检查是否上链:" + err.Error())
	}
	if existed {
		return key, fmt.Errorf("The asset  is existed! the key : %s", key)
	}
	// 4 添加push时间
	if err = addUpdateTime(updateTime, assetStruct); err != nil {
		return key, errors.New("// 4 添加push时间:" + err.Error())
	}
	// 5　上链
	assetAsBytes, err := json.Marshal(assetStruct)
	if err != nil {
		return key, errors.New("// 5　上链:" + err.Error())
	}
	if err = stub.PutState(key, assetAsBytes); err != nil {
		return key, err
	}
	// 6 添加关联关系
	/*	if err = addRelationShipForSubAsset(stub, assetStruct, key); err != nil {
			return key, errors.New("// 6 添加关联关系:"+err.Error())

		}
	*/
	return key, nil
}

// 资产上链 ||应收账款
func uploadAssetInternalRec(stub shim.ChaincodeStubInterface, args []string, assetStruct interface{}) (string, error) {
	var key string
	var err error
	if len(args) != 4 {
		return key, errors.New("Incorrect number of arguments. Expecting 3")
	}
	assetJsonStr := args[1]
	updateTime := args[2]
	logger.Debug("开始步骤")
	//１ 反序列化
	if err := json.Unmarshal([]byte(assetJsonStr), assetStruct); err != nil {
		return key, errors.New("//１ 反序列化:" + err.Error())
	}
	//2 获取上链key
	key, err = getPkey(assetStruct)
	if err != nil {
		return key, errors.New("//2 获取上链:" + err.Error())
	}
	//3 检查是否上链
	existed, err := checkIsExisted(stub, key)
	if err != nil {
		return key, errors.New("//3 检查是否上链:" + err.Error())
	}
	if existed {
		return key, fmt.Errorf("The asset  is existed! the key : %s", key)
	}
	// 4 添加push时间
	if err = addUpdateTime(updateTime, assetStruct); err != nil {
		return key, errors.New("// 4 添加push时间:" + err.Error())
	}
	// 5　上链
	assetAsBytes, err := json.Marshal(assetStruct)
	if err != nil {
		return key, errors.New("// 5　上链:" + err.Error())
	}
	if err = stub.PutState(key, assetAsBytes); err != nil {
		return key, err
	}
	return key, nil
}

//　检查是否上链了
func checkIsExisted(stub shim.ChaincodeStubInterface, key string) (bool, error) {
	// 校验key
	if key == "" {
		return false, errors.New("the pkey‘s value  is empty")
	}
	// 判断链上是否存在
	assetAsBytes, err := stub.GetState(key)
	if err != nil {
		return false, err
	}
	if assetAsBytes != nil {
		return true, nil
	}
	return false, nil
}

// 为结构体添加更新时间
func addUpdateTime(updateTime string, asset interface{}) error {
	v := reflect.ValueOf(asset).Elem()
	v.FieldByName("UpdateDate").SetString(updateTime)
	return nil
}

// 为结构体添加txID
func addUpdateTxID(updateTxID string, asset interface{}) error {
	v := reflect.ValueOf(asset).Elem()
	v.FieldByName("HisCurrentTx").SetString(updateTxID)
	return nil
}

// 为结构体添加更新时间
func addParentInfo(parentID, parentType string, asset interface{}) error {
	v := reflect.ValueOf(asset).Elem()
	v.FieldByName("ParentID").SetString(parentID)
	//v.FieldByName("ParentID")
	v.FieldByName("ParentType").SetString(parentType)
	return nil
}

// 获取上链对象的key
func getPkey(asset interface{}) (string, error) {
	t := reflect.TypeOf(asset).Elem()
	v := reflect.ValueOf(asset).Elem()
	fieldCount := t.NumField()
	for index := 0; index < fieldCount; index++ {
		// 有这个标识的　字段　对应的值
		_, hasKey := t.Field(index).Tag.Lookup("pkey")
		if hasKey {
			return v.FieldByName(t.Field(index).Name).String(), nil
		}
	}
	return "", errors.New("The asset has no field  about primary key!")
}

// 添加资产关联关系
func addRelationShipForSubAsset(stub shim.ChaincodeStubInterface, asset interface{}, assetKey string) error {
	switch v := asset.(type) {
	//基础资产
	case *Assets:
		// id := v.PreRegNo   //产品信息不能强制关联  子资产
		id := v.ProUUID // 资产唯一标识的
		//  为底层资产添加　parentID
		var i interface{}

		//根据资产类型 　　确定需要关联　保理资产　还是　底层资产
		switch v.ProType {
		case "0":
			rrAssetTmp := &ProAttachmentlist{}
			rrAssetTmp.ParentType = assetType_FUJIAN
			i = rrAssetTmp
		default:
			return errors.New("Product assetType only supports 0 and 1 ,　but recived : " + v.ProType)
		}
		if err := changeRelationByArrary(stub, id, v.ProNote, i); err != nil {
			return err
		}
		//  汇总产品信息  key  挂靠到asset下面
		products, err := stub.GetState("UUID-" + v.ProUUID)
		if err != nil {
			return err
		}
		// 如果是 value 为空  直接添加
		if products == nil {
			if err := stub.PutState("UUID-"+v.ProUUID, []byte(assetKey)); err != nil {
				return err
			}
			// 如果不包含这个key　　组装后添加进去
		} else if !strings.Contains(string(products), assetKey) {
			products = []byte(string(products) + "-" + assetKey)
			if err := stub.PutState("UUID-"+v.ProUUID, products); err != nil {
				return err
			}
		}
	}
	return nil
}

//根据key改变其　parentID
// 逻辑：　根据key 获取对象　　判读是否有parentID 　没有的话就赋值
func changeRelationByArrary(stub shim.ChaincodeStubInterface, parentID string, keys []string, asset interface{}) error {
	// 通过反射改值
	v := reflect.ValueOf(asset).Elem()
	parentTypeValue := v.FieldByName("ParentType").String()
	//遍历发票、贸易合同、其他附件集合　　更改其parentID
	for _, key := range keys {
		// 取对象
		objAsBytes, err := stub.GetState(key)
		if err != nil {
			return err
		}
		if objAsBytes == nil {
			return errors.New("The asset  is　not existed! the key :" + key)
		}
		if err := json.Unmarshal(objAsBytes, asset); err != nil {
			return err
		}
		v := reflect.ValueOf(asset).Elem()
		fieldValue := v.FieldByName("ParentID").String()
		if strings.Contains(fieldValue, "<") { //判断值是否为string 类型
			//　非string 类型
			return errors.New(fieldValue)

		} else if len(fieldValue) > 0 { //parentID已经有值了
			continue
		}
		// 　设置父级 id 以及 type
		v.FieldByName("ParentID").SetString(parentID)
		v.FieldByName("ParentType").SetString(parentTypeValue)
		// 存对象
		if objAsBytes, err = json.Marshal(asset); err != nil {
			return err
		}
		if err := stub.PutState(key, objAsBytes); err != nil {
			return err
		}
	}
	return nil
}

// 根据jsonObj 获取　更新时间
func getUpdateTime(str string) string {
	// logger.Debug("getUpdateTime 入参   ： ", str)
	resultStr := ""
	ss := strings.Split(str, ",")
	for _, value := range ss {
		if strings.Contains(value, "updateDate") {
			fieldValue := strings.Split(value, ":")[1]
			resultStr = strings.Split(fieldValue, "\"")[1]
			break
		}
	}
	// logger.Debug("getUpdateTime 结果   ： ", resultStr)
	return resultStr
}

// 资产上链 历史记录上链
func uploadAssetInternalHistory(stub shim.ChaincodeStubInterface, args []string, historyStruct interface{}, TxID string) (string, error) {
	var key string
	var err error
	if len(args) != 4 {
		return key, errors.New("Incorrect number of arguments. Expecting 4")
	}
	assetJsonStrHistory := args[3]
	updateTime := args[2]
	logger.Debug("开始步骤")
	//１ 反序列化
	if err := json.Unmarshal([]byte(assetJsonStrHistory), historyStruct); err != nil {
		return key, errors.New("//１ 反序列化:" + err.Error())
	}
	//2 获取上链key
	key, err = getPkey(historyStruct)
	if err != nil {
		return key, errors.New("//2 获取上链:" + err.Error())
	}
	//3 检查是否上链
	existed, err := checkIsExisted(stub, key)
	if err != nil {
		return key, errors.New("//3 检查是否上链:" + err.Error())
	}
	if existed {
		return key, fmt.Errorf("The asset  is existed! the key : %s", key)
	}
	// 4 添加push时间
	if err = addUpdateTime(updateTime, historyStruct); err != nil {
		return key, errors.New("// 4 添加push时间:" + err.Error())
	}

	// 4 添加tx ID
	if err = addUpdateTxID(TxID, historyStruct); err != nil {
		return key, errors.New("// 4 添加push TxID:" + err.Error())
	}
	// 5　上链
	historyBytes, err := json.Marshal(historyStruct)
	if err != nil {
		return key, errors.New("// 5　上链:" + err.Error())
	}
	if err = stub.PutState(key, historyBytes); err != nil {
		return key, err
	}

	return key, nil
}
