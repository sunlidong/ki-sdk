package main

/**
* Main
* @lidong sun
* @Time 2019年10月14日10:25:50
*
 */
import (
	"dlchain_1015/model/action"
	m_api "dlchain_1015/model/api"
	r_action "dlchain_1015/router/action"
	r_api "dlchain_1015/router/api"
	"fmt"
	"log"
)

func main() {

	//	01. 初始化 sdk
	err := m_api.GetSDK()
	if err != nil {
		fmt.Errorf("初始化配置文件出错:%v", err)
		return
	}

	// 	- 轮询器
	//go m_api.Poller()

	// 初始化数据库
	//	02.	初始化路由
	action.SqlByInitByDB()

	routerServer := r_api.GetRouter(int64(1))
	routerServer.Run(r_action.Port_01)

	//	03. 提示启动成功
	log.Println("服务启动成功.....")
}
